<?php
/**
 * Plugin Name: BOOTSTRAP STYLE/SCRIPT
 * Plugin URI: http://123.207.74.118/
 * Description: 引入bootstrap样式与插件
 * Version: 0.1
 * Author: DHM
 * Author URI: #
 * License: GPL2
 */

function StyleAndScriptToHome(){
	$css_uri=plugins_url('css/bootstrap.improve.css',__FILE__);
	wp_enqueue_style('bootstrap.improve.css',$css_uri);
	$js_uri=plugins_url('js/bootstrap.min.js',__FILE__);
	wp_enqueue_script('bootstrap.min.js',$js_uri);
}



add_action("wp_head","StyleAndScriptToHome");
// add_action("admin_enqueue_scripts","StyleAndScriptToHome");