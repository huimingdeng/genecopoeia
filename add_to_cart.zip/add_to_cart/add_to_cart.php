<?php
/**
 * Plugin Name: add_to_cart
 * Plugin URI: #
 * Description: 添加产品到用户的购物车.(弹窗使用bootrap模态框)
 * Author: DHM
 * Author URI: #
 * Version: 0.3
 */

  function active_js(){
	  //插件所在项目的加载路径，以及加载的js目录和js名称
	  $js_uri=plugins_url('js/add_to_cart.js',__FILE__);
	  wp_enqueue_script('add_to_cart.js',$js_uri);
	  $css_uri=plugins_url('css/add_to_cart.css',__FILE__);
	  wp_enqueue_style('add_to_cart.css',$css_uri);
?>
<div class="modal fade" id="cart_tip" tabindex="-1" role="dialog" aria-labelledby="cartModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="cartModalLabel">add_to_cart</h4>
			</div>
			<div class="modal-body"></div>
		</div>
	</div>
</div><!-- cart_tip end -->
<?php $editFormAction = ($_SERVER['PHP_SELF'])? '/login/index.php'."?url=" . urlencode($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']):'/login/index.php';
	//$editFormAction = '/login/?url='.$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
?>
<div class="modal fade" id="loginform" tabindex="-1" role="dialog" aria-labelledby="formtitle" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="formtitle">Please Sign in.</h4>
			</div>
			<div class="modal-body">
				<form method="POST" name="form1" action="<?php echo $editFormAction; ?>">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input name="log_email" value="" class="form-control" id="email" size="32" type="text">
                    </div>
                    <div class="checkbox">
                        <label><input name="log_save" value="1" type="checkbox">Save the information for login automatically</label>
                    </div>
                    <div class="form-group">
                        <input value="Login" class="btn btn-success" style="color:#fff;" type="submit">&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="/login/register.php?url=<?php echo urlencode( $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'] );?>" class="btn btn-default">Register</a>
                    </div>
                    <input name="MM_update" value="form1" type="hidden">
                    <input name="url" value="/order/" type="hidden">
                    <input name="utm_content" value="login" type="hidden">
                </form>
			</div>
		</div>
	</div>
</div><!-- loginform end -->
<?php }
add_action('wp_footer','active_js');?>