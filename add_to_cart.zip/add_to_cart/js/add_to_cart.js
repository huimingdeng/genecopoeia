
jQuery(document).ready(function($){
    //表单提交
    $('form').submit(function(){
        //正则匹配，表单提交地址为"/order/cart_add.php"
        if(/\/order\/cart_add.php/.test($(this).attr('action') ) ){
            var cat_no=$(this).find('input[type=checkbox]').is(":checked");
            if( cat_no ){
                var url='/order/cart_add.php?action=api';
                var data=$(this).serialize();
                $.ajax({
                    url:url,
                    type:'GET',
                    data:data,
                    dataType:'json',
                    success:function(msg){
                        if(msg.status!='fail'){
                            //获得当前购物车商品数量
                            $.ajax({
                                url: '/order/shopping_cart_api.php',
                                type: 'GET',
                                dataType: 'json'
                            })
                                .done(function(msg) {
                                    if(msg.status=="ok"){
                                        $(".shopping_cart .badge").text(msg.total);
                                    }
                                })
                                .fail(function() {
                                    console.log("Network error.");
                                });
                            var strHtml='';
                            strHtml+='&nbsp;&nbsp;';
                            strHtml+="<p style='text-align:center; font-size:18px; padding:10px;'>Whether to enter the shopping cart?";
                            strHtml+='&nbsp;&nbsp;';
                            strHtml+="<a href='/order/' class='btn btn-success' style='color:#fff;'>My shopping cart</a>&nbsp;</p>";
                            $("#cart_tip").modal(
                                $("#cartModalLabel").text(msg.info),
                                $("#cart_tip .modal-body").html(strHtml),
                                setTimeout(function(){$("#cart_tip").modal('hide')},3000)
                            );
                        }else{
                            //如果未登录
                            if(msg.status=='fail'&&msg.info=='Please login first'){
                                $("#loginform").modal('show');
                            }else if(msg.status=='fail'&&msg.info=='No product added.'){
                                var strHtml='';
                                strHtml+='<p style="text-align:center; font-size:18px; padding:10px;">';
                                strHtml+='&nbsp;The product has been added to the shopping cart.&nbsp;';
                                strHtml+='</p>';
                                $("#cart_tip").modal(
                                    $("#cartModalLabel").text(msg.info),
                                    $("#cart_tip .modal-body").html(strHtml),
                                    setTimeout(function(){$("#cart_tip").modal('hide')},3000)
                                );
                            }else{
                                var strHtml='';
                                strHtml+='<p style="text-align:center; font-size:18px; padding:10px;">';
                                strHtml+='&nbsp;'+msg.info+'&nbsp;';
                                strHtml+='</p>';
                                $("#cart_tip").modal(
                                    $("#cartModalLabel").text(msg.status),
                                    $("#cart_tip .modal-body").html(strHtml),
                                    setTimeout(function(){$("#cart_tip").modal('hide')},3000)
                                );
                            }
                        }
                    }
                });
                return false;
            }else{
                var strHtml='';
                strHtml+='<p style="text-align:center; font-size:18px; padding:10px;">';
                strHtml+='Please select products!';
                strHtml+='</p>';
                $("#cart_tip").modal(
                    $("#cartModalLabel").text('Prompt'),
                    $("#cart_tip .modal-body").html(strHtml),
                    setTimeout(function(){$("#cart_tip").modal('hide')},3000)
                );
                return false;
            }
            return false;
        }
    });
});